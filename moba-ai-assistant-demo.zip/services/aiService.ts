import { AI_RESPONSES } from '../constants';
import { GameState } from '../types';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getAIResponse = async (query: string, gameState: GameState): Promise<string> => {
  await delay(1200 + Math.random() * 800); // 1.2s - 2.0s delay

  const lowerQuery = query.toLowerCase();

  // Basic keyword matching to simulate AI context awareness
  if (gameState === GameState.DEAD || lowerQuery.includes('死') || lowerQuery.includes('died')) {
    return AI_RESPONSES.DEATH_ANALYSIS;
  }
  
  if (gameState === GameState.SHOPPING || lowerQuery.includes('买') || lowerQuery.includes('装备') || lowerQuery.includes('buy')) {
    return AI_RESPONSES.SHOP_ADVICE;
  }

  if (lowerQuery.includes('打野') || lowerQuery.includes('龙') || lowerQuery.includes('jungle')) {
    return AI_RESPONSES.JUNGLE_TRACKING;
  }
  
  if (lowerQuery.includes('心态') || lowerQuery.includes('输') || lowerQuery.includes('lose')) {
    return AI_RESPONSES.ENCOURAGEMENT;
  }

  return AI_RESPONSES.DEFAULT;
};