
import React, { useState, useEffect, useRef } from 'react';
import GameHUD from './components/GameHUD';
import ControlPanel from './components/ControlPanel';
import { ProductMode, GameState, ChatMessage, PipelineLog } from './types';
import { INITIAL_CHAT_HISTORY, AI_NAME, AI_RESPONSES } from './constants';
import { getAIResponse } from './services/aiService';

const App: React.FC = () => {
  const [currentMode, setCurrentMode] = useState<ProductMode>(ProductMode.GUIDED_QUERY);
  const [gameState, setGameState] = useState<GameState>(GameState.NORMAL);
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_HISTORY);
  const [pipelineLogs, setPipelineLogs] = useState<PipelineLog[]>([]);
  const [isDuplexActive, setIsDuplexActive] = useState(false);

  const [aiState, setAiState] = useState({
    isListening: false,
    isSpeaking: false,
    response: null as string | null,
    timer: 0,
    isThinking: false
  });

  const timerIntervalRef = useRef<number | null>(null);
  const speechTimeoutRef = useRef<number | null>(null);

  const addPipelineLog = (role: PipelineLog['role'], content: string) => {
    const time = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setPipelineLogs(prev => [...prev.slice(-40), { id: Math.random().toString(), role, content, timestamp: time }]);
  };

  const addChatMessage = (sender: ChatMessage['sender'], text: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })
    }]);
  };

  // 控制台全链路步进逻辑：显著放慢展示节奏
  const runPipelineFlow = async (query: string) => {
    addPipelineLog('ASR', `实时语音转文本: "${query}"`);
    await new Promise(r => setTimeout(r, 1200));
    addPipelineLog('VAD', 'VAD检测：语音输入结束');
    await new Promise(r => setTimeout(r, 800));
    addPipelineLog('NLP', 'NLU处理：解析意图 [游戏策略建议]');
    await new Promise(r => setTimeout(r, 1000));
    addPipelineLog('LLM', '大模型检索知识库 (RAG)...');
    await new Promise(r => setTimeout(r, 1500));
    addPipelineLog('LLM', '推理完成：生成响应内容');
    await new Promise(r => setTimeout(r, 600));
    addPipelineLog('TTS', 'TTS流式音频下发：音色 [海克斯-知性]');
  };

  const handleAIInteraction = async (query: string, isAuto: boolean = false) => {
    const isVoiceMode = [ProductMode.SINGLE_TURN_VOICE, ProductMode.MULTI_TURN_VOICE, ProductMode.FULL_DUPLEX].includes(currentMode);

    if (isVoiceMode) {
      await runPipelineFlow(query);
    }

    // 形态 2 (文本) 几乎瞬时返回，不显示思考状态
    if (currentMode === ProductMode.TEXT_CHAT) {
      const response = await getAIResponse(query, gameState); // 虽然有delay，但逻辑模拟上这里可以加速
      addChatMessage('ai', response);
      return;
    }

    setAiState(prev => ({ ...prev, isSpeaking: true, isThinking: true }));
    const response = isAuto ? AI_RESPONSES.PROACTIVE_Q : await getAIResponse(query, gameState);
    
    setAiState(prev => ({ ...prev, isThinking: false, response }));

    // 播放持续时间，形态 5 模拟多轮时更快完成
    const playDuration = 4000;
    speechTimeoutRef.current = window.setTimeout(() => {
      if (isVoiceMode) addPipelineLog('TTS', '音频播放轨道结束');
      setAiState(prev => ({ ...prev, isSpeaking: false, response: null }));
    }, playDuration);
  };

  const handleSendMessage = (text: string) => {
    if (currentMode === ProductMode.TEXT_CHAT) {
      addChatMessage('player', text);
      if (text.toLowerCase().includes('@ai')) {
        handleAIInteraction(text.replace(/@ai/gi, '').trim() || "在的，召唤师");
      }
    } else {
      handleAIInteraction(text);
    }
  };

  // 形态 4: 窗口模式处理
  useEffect(() => {
    if (currentMode === ProductMode.MULTI_TURN_VOICE && aiState.isListening) {
      setAiState(prev => ({ ...prev, timer: 30 }));
      timerIntervalRef.current = window.setInterval(() => {
        setAiState(prev => {
          if (prev.timer <= 1) {
            clearInterval(timerIntervalRef.current!);
            return { ...prev, isListening: false, timer: 0 };
          }
          return { ...prev, timer: prev.timer - 1 };
        });
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => { if (timerIntervalRef.current) clearInterval(timerIntervalRef.current); };
  }, [aiState.isListening, currentMode]);

  const handleVoiceTrigger = (start: boolean) => {
    if (currentMode === ProductMode.MULTI_TURN_VOICE) {
      // 模式 4 改为点击切换，支持窗口期内多次模拟
      if (!aiState.isListening) {
        setAiState(prev => ({ ...prev, isListening: true }));
        addPipelineLog('SYSTEM', '启动 30s 实时监听窗口期');
      } else {
        // 模拟用户在窗口期内说话
        addPipelineLog('USER_ACTION', '检测到窗口期内用户输入');
        handleAIInteraction("对面打野不见了，我该撤退吗？");
      }
    } else if (currentMode === ProductMode.SINGLE_TURN_VOICE) {
      // 模式 3 保持传统按住模式（作为对比）
      if (start) {
        setAiState(prev => ({ ...prev, isListening: true }));
        addPipelineLog('SYSTEM', '启动单次麦克风捕捉');
      } else {
        setAiState(prev => ({ ...prev, isListening: false }));
        handleAIInteraction("团战怎么切入？");
      }
    }
  };

  const toggleDuplex = () => {
    const active = !isDuplexActive;
    setIsDuplexActive(active);
    if (active) {
      addPipelineLog('SYSTEM', '全双工 (Full Duplex) 长连接握手完成');
      addPipelineLog('ASR', '实时特征提取引擎启动...');
      
      // 模拟 5 秒后 AI 主动发问
      setTimeout(() => {
        if (isDuplexActive) {
          addPipelineLog('SYSTEM', 'AI主动策略触发：检测到关键资源刷新');
          handleAIInteraction("", true);
        }
      }, 5000);
    } else {
      addPipelineLog('SYSTEM', '全双工通道正常关闭');
    }
  };

  // 全双工打断模拟逻辑
  const simulateInterrupt = () => {
    if (isDuplexActive && aiState.isSpeaking) {
      if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
      addPipelineLog('USER_ACTION', '>>> 用户强行打断 (Barge-in) <<<');
      addPipelineLog('SYSTEM', '中断指令下发：清空音频缓冲区');
      setAiState(prev => ({ ...prev, isSpeaking: false, response: null }));
      
      setTimeout(() => {
        addPipelineLog('ASR', '捕获新语音流: "别说了，先看上路..."');
        handleAIInteraction("上路塔快掉了，我传不传？");
      }, 1000);
    }
  };

  return (
    <div className="flex w-screen h-screen bg-black overflow-hidden text-white font-game" onContextMenu={(e) => {
      e.preventDefault();
      simulateInterrupt();
    }}>
      <div className="flex-1 relative">
        <GameHUD 
          mode={currentMode}
          gameState={gameState}
          onGameStateChange={setGameState}
          messages={messages}
          pipelineLogs={pipelineLogs}
          onSendMessage={handleSendMessage}
          aiState={aiState}
          onTriggerVoice={handleVoiceTrigger}
          onToggleDuplex={toggleDuplex}
          isDuplexActive={isDuplexActive}
        />
        {isDuplexActive && aiState.isSpeaking && (
          <div className="absolute bottom-10 right-10 bg-red-600/80 px-4 py-2 rounded-full animate-bounce text-[10px] font-bold border border-white/20">
            右键屏幕模拟实时打断 (Barge-in)
          </div>
        )}
      </div>

      <ControlPanel 
        currentMode={currentMode}
        onModeChange={(m) => {
          setCurrentMode(m);
          setPipelineLogs([{ id: 'init', role: 'SYSTEM', content: `切换至交互形态: ${ProductMode[m]}`, timestamp: '--:--:--' }]);
          setAiState({ isListening: false, isSpeaking: false, response: null, timer: 0, isThinking: false });
          setIsDuplexActive(false);
          if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
        }}
        currentState={gameState}
        onStateChange={setGameState}
      />
    </div>
  );
};

export default App;
